package com.gopa.controller;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.util.UriComponentsBuilder;

import com.gopa.model.Task;
import com.gopa.service.TestService;


@RestController
@RequestMapping("/api")
public class TestController {
	 public static final Logger logger = LogManager.getLogger(TestController.class);
	 
	 @Autowired
	 TestService testService;

	 @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity<Task> getTaskById(@PathVariable("id") long id) {
	        System.out.println("Fetching task with id " + id);
	        Task task = testService.findById(id);
	        if (task == null) {
	            return new ResponseEntity<Task>(HttpStatus.NOT_FOUND);
	        }
	        return new ResponseEntity<Task>(task, HttpStatus.OK);
	    }

	    @PostMapping(value="/create",headers="Accept=application/json")
	    public ResponseEntity<Void> createtask(@RequestBody Task task, UriComponentsBuilder ucBuilder){
	        System.out.println("Creating task "+task.getTaskName());
	        testService.createTask(task);
	        HttpHeaders headers = new HttpHeaders();
	        headers.setLocation(ucBuilder.path("/task/{id}").buildAndExpand(task.getTaskId()).toUri());
	        return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	    }

	    @GetMapping(value="/get", headers="Accept=application/json")
	    public List<Task> getAlltask() {
	        List<Task> tasks=testService.getTasks();
	        return tasks;

	    }

	    @PutMapping(value="/update", headers="Accept=application/json")
	    public ResponseEntity<String> updatetask(@RequestBody Task currentTask)
	    {
	        System.out.println("sd");
	        Task task = testService.findById(currentTask.getTaskId());
	        if (task==null) {
	            return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
	        }
	        testService.update(currentTask, task.getTaskId());
	        return new ResponseEntity<String>(HttpStatus.OK);
	    }

	    @DeleteMapping(value="/{id}", headers ="Accept=application/json")
	    public ResponseEntity<Task> deletetask(@PathVariable("id") long id){
	        Task task = testService.findById(id);
	        if (task == null) {
	            return new ResponseEntity<Task>(HttpStatus.NOT_FOUND);
	        }
	        testService.deleteTaskById(id);
	        return new ResponseEntity<Task>(HttpStatus.NO_CONTENT);
	    }

	    @PatchMapping(value="/{id}", headers="Accept=application/json")
	    public ResponseEntity<Task> updatetaskPartially(@PathVariable("id") long id, @RequestBody Task currenttask){
	        Task task = testService.findById(id);
	        if(task ==null){
	            return new ResponseEntity<Task>(HttpStatus.NOT_FOUND);
	        }
	        Task tsk = testService.updatePartially(currenttask, id);
	        return new ResponseEntity<Task>(tsk, HttpStatus.OK);
	    }

	    
}
