package com.gopa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gopa.dao.TestDao;
import com.gopa.model.Task;

@Service
public class TestService {
	
	@Autowired
	TestDao testDao;

	public void createTask(Task task) {
		testDao.createTask(task);
	}
    public List<Task> getTasks(){
       return testDao.getTasks();
    }
    public Task findById(long id) {
    	return testDao.findById(id);
    }
    public Task update(Task user, long l) {
    	return testDao.update(user,l);
    }
    public void deleteTaskById(long id) {
    	testDao.deleteTaskById(id);
    }
    public Task updatePartially(Task user, long id) {
    	return testDao.updatePartially(user,id);
    }
    	
	/*
	 * public int save(Task task) { return testDao.save(task); }
	 */
}
