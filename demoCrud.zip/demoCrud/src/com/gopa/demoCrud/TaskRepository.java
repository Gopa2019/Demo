package com.gopa.demoCrud;

import org.springframework.data.repository.CrudRepository;

import com.gopa.model.Task;

public interface TaskRepository extends CrudRepository<Task, Long> {
	
} 

