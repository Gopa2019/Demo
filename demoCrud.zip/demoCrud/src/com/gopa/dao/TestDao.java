package com.gopa.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.gopa.demoCrud.TaskRepository;
import com.gopa.model.Task;

@Repository
public class TestDao {
	
	@Autowired
    TaskRepository taskRepository;

	@Autowired
	JdbcTemplate jdbcTemplate;
	private Logger logger = LogManager.getLogger(TestDao.class);


	public void createTask(Task task) {
		taskRepository.save(task);
		
	}

	public List<Task> getTasks() {
		return (List<Task>) taskRepository.findAll();
	}

	public Task findById(long id) {
		 return taskRepository.findOne(id);
	}

	public Task update(Task user, long l) {
		return taskRepository.save(user);
		
	}

	public void deleteTaskById(long id) {
		taskRepository.delete(id);
		
	}

	public Task updatePartially(Task task, long id) {
		 Task tas = findById(id);
		 tas.setTaskPriority(tas.getTaskPriority());
	     return taskRepository.save(tas);
	}

	
}
